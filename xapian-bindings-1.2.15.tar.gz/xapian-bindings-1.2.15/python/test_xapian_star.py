# Module used to test that "from xapian import *" works
# This needs to be a separate module because the syntax is only valid at module
# level.
from xapian import *
