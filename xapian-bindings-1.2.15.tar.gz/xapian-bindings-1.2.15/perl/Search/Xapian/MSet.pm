package Search::Xapian::MSet;

1;
