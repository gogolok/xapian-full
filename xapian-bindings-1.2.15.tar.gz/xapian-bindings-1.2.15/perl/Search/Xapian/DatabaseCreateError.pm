package Search::Xapian::DatabaseCreateError;

=head1 NAME

Search::Xapian::DatabaseCreateError -  DatabaseCreateError indicates a failure to create a database. 


=head1 DESCRIPTION


=cut
1;
