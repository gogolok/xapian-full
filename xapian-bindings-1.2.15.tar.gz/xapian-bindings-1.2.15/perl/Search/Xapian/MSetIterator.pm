package Search::Xapian::MSetIterator;

1;
